"""
Koncepcja:
1. Mamy 12 miesiecy wybieramy miesiac
2. w danym miesiacu mozemy dodac wydatek i wystwitlic wydatki (pomysl o dodatkowych funkcjach)
3. ... statystyki
"""